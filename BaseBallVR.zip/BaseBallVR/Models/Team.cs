﻿using System.ComponentModel.DataAnnotations;

namespace BaseBallVR.Models
{
    public class Team
    {
        [Key]
        [MaxLength(30)]
        public string Id { get; set; }

        [MaxLength(30)]
        public string teamName { get; set; }
    }

    public class TeamViewModel
    {
        public string Id { get; set; }
        public string teamName { get; set; }
    }


}
