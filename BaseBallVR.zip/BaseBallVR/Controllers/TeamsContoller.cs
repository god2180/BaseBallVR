﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using BaseBallVR.DB;

using AutoMapper;
using BaseBallVR.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace BaseBallVR.Controllers
{
    [Route("api/teams")]
    public class TeamsController : Controller
    {
        private readonly ITeamRepository _teamRepository;
        
        public TeamsController(ITeamRepository teamRepository)
        {
            _teamRepository = teamRepository;
        }
       
        [HttpGet("{Id}/{teamName}")]

        public IActionResult Create(string Id, string teamName)
        {
            try
            {
                var newTeam = new Team
                {
                    Id =Id,
                    teamName = teamName
                };

                _teamRepository.Add(newTeam);
                _teamRepository.Commit();

                var team = Mapper.Map<Team, TeamViewModel>(newTeam);

                 return new OkObjectResult(team);
            }

            catch(Exception ex)
            {
                return NotFound(ex);
            }
        }

        // GET api/<controller>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<controller>
        [HttpPost]
        public void Post([FromBody]string value)
        {
        }

        // PUT api/<controller>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/<controller>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
