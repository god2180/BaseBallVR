﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using BaseBallVR.Models;

namespace BaseBallVR.DB
{
    
   
    public interface ITeamRepository
    {
        IEnumerable<Team> Allincluding(params Expression<Func<Team, object>>[] includeProperties);
        IEnumerable<Team> GetAll();
        int Count();
        Team GetSingle(string id);
        Team GetSingle(Expression<Func<Team, bool>> predicate);
        Team GetSingle(Expression<Func<Team, bool>> predicatem, params Expression<Func<Team, object>>[] includeProperties);
        IEnumerable<Team> FindBy(Expression<Func<Team, bool>> predicate);

        void Add(Team entity);
        void Update(Team entity);
        void Delete(Team entity);
        void DeleteWhere(Expression<Func<Team, bool>> predicate);
        void Commit();
    }
   
    public class TeamRepository : ITeamRepository
    {
        private TeamContext _context;

        public TeamRepository(TeamContext context)
        {
            _context = context;
        }

        public virtual IEnumerable<Team> GetAll()
        {
            return _context.Set<Team>().AsEnumerable();
        }

        public virtual int Count()
        {
            return _context.Set<Team>().Count();
        }

        public virtual IEnumerable<Team> Allincluding(params Expression<Func<Team, object>>[] includeProperties)
        {
            IQueryable<Team> query = _context.Set<Team>();
            foreach(var includeProperty in includeProperties)
            {
                query = query.Include(includeProperty);
            }

            return query.AsEnumerable();
        }

        public Team GetSingle(string id)
        {
            return _context.Set<Team>().FirstOrDefault(x => x.Id == id);
        }

        public Team GetSingle(Expression<Func<Team, bool>> predicate)
        {
            return _context.Set<Team>().FirstOrDefault(predicate);
        }

        public Team GetSingle(Expression<Func<Team, bool>> predicate, params Expression<Func<Team, object>>[] includeProperties)
        {
            IQueryable<Team> query = _context.Set<Team>();
            foreach(var includeProperty in includeProperties)
            {
                query = query.Include(includeProperty);
            }

            return query.Where(predicate).FirstOrDefault();
        }

        public virtual IEnumerable<Team> FindBy(Expression<Func<Team, bool>> predicate)
        {
            return _context.Set<Team>().Where(predicate);
        }

        public virtual void Add(Team entity)
        {
            EntityEntry dbEntityEntry = _context.Entry<Team>(entity);
            _context.Set<Team>().Add(entity);
        }

        public virtual void Update(Team entity)
        {
            EntityEntry dbEntityEntry = _context.Entry<Team>(entity);
            dbEntityEntry.State = EntityState.Modified;
        }

        public virtual void Delete(Team entity)
        {
            EntityEntry dbEntityEntry = _context.Entry<Team>(entity);
            dbEntityEntry.State = EntityState.Deleted;
        }

        public virtual void DeleteWhere(Expression<Func<Team, bool>> predicate)
        {
            IEnumerable<Team> entities = _context.Set<Team>().Where(predicate);

            foreach(var entity in entities)
            {
                _context.Entry<Team>(entity).State = EntityState.Deleted;
            }
        }

        public virtual void Commit()
        {
            _context.SaveChanges();
        }
    }
}